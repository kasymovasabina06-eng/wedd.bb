// Telegram credentials must be configured as server-side Environment Variables.
// Never place a bot token in public GitHub files.

const allowedAnswers = new Set([
    "Ооба, сөзсүз келем",
    "Тилекке каршы, келе албайм"
]);

function json(statusCode, payload) {
    return {
        statusCode,
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Cache-Control": "no-store"
        },
        body: JSON.stringify(payload)
    };
}

exports.handler = async function (event) {
    if (event.httpMethod !== "POST") {
        return json(405, { ok: false, error: "method_not_allowed" });
    }

    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!token || !chatId) {
        return json(503, { ok: false, error: "telegram_not_configured" });
    }

    let body;
    try {
        body = JSON.parse(event.body || "{}");
    } catch (error) {
        return json(400, { ok: false, error: "invalid_json" });
    }

    const name = String(body.name || "").trim().slice(0, 100);
    const companion = String(body.companion || "").trim().slice(0, 100);
    const attendance = String(body.attendance || "").trim();
    const honeypot = String(body.website || "").trim();

    if (honeypot) return json(200, { ok: true });
    if (name.length < 2 || !allowedAnswers.has(attendance)) {
        return json(400, { ok: false, error: "invalid_form" });
    }

    const message = [
        "💍 РУСТАМ & ПАРИЗАТ — ТОЙГО ЖООП",
        "",
        `👤 Аты-жөнү: ${name}`,
        `👥 Ким менен келет: ${companion || "Жалгыз"}`,
        `✅ Жообу: ${attendance}`,
        "",
        "📅 20.06.2027",
        "📍 Өтүүчү жай такталууда",
        "🕔 Коноктордун чогулушу: 17:00",
        "🕕 Тойдун башталышы: 18:00"
    ].join("\n");

    try {
        const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                chat_id: chatId,
                text: message,
                disable_web_page_preview: true
            })
        });
        const result = await response.json();

        if (!response.ok || !result.ok) {
            return json(502, { ok: false, error: "telegram_rejected" });
        }
        return json(200, { ok: true });
    } catch (error) {
        return json(502, { ok: false, error: "telegram_unavailable" });
    }
};
