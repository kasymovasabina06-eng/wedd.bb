module.exports = async function handler(req, res) {
    if (req.method !== "POST") return res.status(405).json({ ok: false, error: "method_not_allowed" });
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;
    if (!token || !chatId) return res.status(503).json({ ok: false, error: "telegram_not_configured" });
    const body = req.body || {};
    const name = String(body.name || "").trim().slice(0, 100);
    const companion = String(body.companion || "").trim().slice(0, 100);
    const attendance = String(body.attendance || "").trim();
    if (String(body.website || "").trim()) return res.status(200).json({ ok: true });
    if (name.length < 2 || !["Ооба, сөзсүз келем", "Тилекке каршы, келе албайм"].includes(attendance)) {
        return res.status(400).json({ ok: false, error: "invalid_form" });
    }
    const text = [
        "💍 РУСТАМ & ПАРИЗАТ — ТОЙГО ЖООП", "", "👤 Аты-жөнү: " + name,
        "👥 Ким менен келет: " + (companion || "Жалгыз"), "✅ Жообу: " + attendance,
        "", "📅 20.06.2027", "📍 Өтүүчү жай такталууда", "🕔 Коноктордун чогулушу: 17:00", "🕕 Тойдун башталышы: 18:00"
    ].join("\n");
    try {
        const response = await fetch("https://api.telegram.org/bot" + token + "/sendMessage", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true })
        });
        const result = await response.json();
        if (!response.ok || !result.ok) return res.status(502).json({ ok: false, error: "telegram_rejected" });
        return res.status(200).json({ ok: true });
    } catch (error) {
        return res.status(502).json({ ok: false, error: "telegram_unavailable" });
    }
};
